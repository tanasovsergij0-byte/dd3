package local.potatomode;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** config/potatomode.properties. Создаётся при первом запуске. */
public final class Config {
    // Клиент
    public static boolean applyClientSettings = true; // ставить лёгкие настройки при каждом запуске
    public static int renderDistance = 6;
    public static int simulationDistance = 5;
    public static double entityDistanceScaling = 0.5;
    // Сервер / одиночная игра
    public static int checkInterval = 100; // тиков между проверками
    public static int maxItems = 150;      // лимит выброшенных предметов на мир
    public static int maxMobs = 120;       // лимит обычных мобов на мир
    public static int minDistance = 24;    // мобов ближе к игроку не трогаем

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("potatomode.properties");
        Properties p = new Properties();
        try {
            if (Files.exists(file)) {
                try (Reader r = Files.newBufferedReader(file)) { p.load(r); }
            } else {
                p.setProperty("applyClientSettings", String.valueOf(applyClientSettings));
                p.setProperty("renderDistance", String.valueOf(renderDistance));
                p.setProperty("simulationDistance", String.valueOf(simulationDistance));
                p.setProperty("entityDistanceScaling", String.valueOf(entityDistanceScaling));
                p.setProperty("checkInterval", String.valueOf(checkInterval));
                p.setProperty("maxItems", String.valueOf(maxItems));
                p.setProperty("maxMobs", String.valueOf(maxMobs));
                p.setProperty("minDistance", String.valueOf(minDistance));
                try (Writer w = Files.newBufferedWriter(file)) { p.store(w, "PotatoMode config"); }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        applyClientSettings = Boolean.parseBoolean(p.getProperty("applyClientSettings", "true").trim());
        renderDistance = Math.max(2, Math.min(32, i(p, "renderDistance", renderDistance)));
        simulationDistance = Math.max(5, Math.min(32, i(p, "simulationDistance", simulationDistance)));
        entityDistanceScaling = Math.max(0.5, Math.min(5.0, d(p, "entityDistanceScaling", entityDistanceScaling)));
        checkInterval = Math.max(20, i(p, "checkInterval", checkInterval));
        maxItems = Math.max(10, i(p, "maxItems", maxItems));
        maxMobs = Math.max(10, i(p, "maxMobs", maxMobs));
        minDistance = Math.max(0, i(p, "minDistance", minDistance));
    }

    private static int i(Properties p, String k, int def) {
        try { return Integer.parseInt(p.getProperty(k, String.valueOf(def)).trim()); }
        catch (NumberFormatException e) { return def; }
    }

    private static double d(Properties p, String k, double def) {
        try { return Double.parseDouble(p.getProperty(k, String.valueOf(def)).trim()); }
        catch (NumberFormatException e) { return def; }
    }
}
