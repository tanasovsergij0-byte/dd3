package local.potatomode;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Серверная часть: лимит предметов и обычных мобов в каждом мире. */
public class PotatoMode implements ModInitializer {
    @Override
    public void onInitialize() {
        Config.load();
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % Config.checkInterval != 0) return;
            for (ServerLevel level : server.getAllLevels()) {
                trim(level);
            }
        });
    }

    private static void trim(ServerLevel level) {
        List<ServerPlayer> players = level.players();
        double minSq = (double) Config.minDistance * Config.minDistance;

        List<ItemEntity> items = new ArrayList<>();
        List<Mob> candidates = new ArrayList<>();
        int mobTotal = 0;

        for (Entity e : level.getAllEntities()) {
            if (e.isRemoved()) continue;
            if (e instanceof ItemEntity item) {
                items.add(item);
            } else if (e instanceof Mob mob) {
                mobTotal++;
                if (mob.isPersistenceRequired() || mob.hasCustomName() || mob.isLeashed()) continue;
                if (players.isEmpty() || nearestSq(mob, players) < minSq) continue;
                candidates.add(mob);
            }
        }

        // Предметы: удаляем самые старые
        int itemExcess = items.size() - Config.maxItems;
        if (itemExcess > 0) {
            items.sort(Comparator.comparingInt(ItemEntity::getAge).reversed());
            for (int i = 0; i < itemExcess; i++) items.get(i).discard();
        }

        // Мобы: удаляем самых далёких от игроков
        int mobExcess = mobTotal - Config.maxMobs;
        if (mobExcess > 0 && !candidates.isEmpty()) {
            candidates.sort(Comparator.comparingDouble((Mob m) -> nearestSq(m, players)).reversed());
            for (int i = 0; i < Math.min(mobExcess, candidates.size()); i++) candidates.get(i).discard();
        }
    }

    private static double nearestSq(Mob mob, List<ServerPlayer> players) {
        double best = Double.MAX_VALUE;
        for (ServerPlayer p : players) best = Math.min(best, mob.distanceToSqr(p));
        return best;
    }
}
