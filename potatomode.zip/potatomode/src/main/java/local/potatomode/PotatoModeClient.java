package local.potatomode;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

/** Клиентская часть: один раз за запуск ставит лёгкие настройки графики. */
public class PotatoModeClient implements ClientModInitializer {
    private boolean applied = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (applied || mc.options == null) return;
            applied = true;
            if (Config.applyClientSettings) apply(mc.options);
        });
    }

    private static void apply(Options o) {
        o.renderDistance().set(Config.renderDistance);
        o.simulationDistance().set(Config.simulationDistance);
        o.entityDistanceScaling().set(Config.entityDistanceScaling);
        o.particles().set(ParticleStatus.MINIMAL);
        o.cloudStatus().set(CloudStatus.OFF);
        o.biomeBlendRadius().set(0);
        o.save();
    }
}
