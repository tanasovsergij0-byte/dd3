PotatoMode для Fabric 1.21.11

ВАРИАНТ А: собрать онлайн (ничего ставить не надо)
1. Зарегистрируйтесь на github.com, создайте новый репозиторий (New repository).
2. Распакуйте этот архив. Нажмите "uploading an existing file" и перетащите
   ВСЁ содержимое папки potatomode, включая скрытую папку .github.
3. Нажмите Commit changes.
4. Вкладка Actions -> workflow "build" -> дождитесь зелёной галочки (2-5 минут).
   Если не запустился: выберите "build" -> Run workflow.
5. Откройте завершённый запуск, внизу в Artifacts скачайте potatomode-jar.
   Внутри будет potatomode-1.0.0.jar.

ВАРИАНТ Б: собрать у себя
1. Установите JDK 21 и Gradle 9.4+ (gradle.org/install).
2. В папке проекта: gradle build
3. Готовый файл: build/libs/potatomode-1.0.0.jar

УСТАНОВКА
Положите potatomode-1.0.0.jar и Fabric API 0.141.x для 1.21.11 в папку mods.
Настройки: config/potatomode.properties (появится после первого запуска).
